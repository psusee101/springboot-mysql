package wipro.springboot.jpa.angularjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AngularJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
