package wipro.springboot.jpa.angularjpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AngularJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AngularJpaApplication.class, args);
	}

}
